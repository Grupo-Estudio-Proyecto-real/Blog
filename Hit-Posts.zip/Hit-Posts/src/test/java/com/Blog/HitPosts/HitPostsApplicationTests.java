package com.Blog.HitPosts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HitPostsApplicationTests {

	@Test
	void contextLoads() {
	}

}
